msg = "hello
print(msg)
