i = 0
while i < 3 && i >= 0:
    print(i)
    i++
