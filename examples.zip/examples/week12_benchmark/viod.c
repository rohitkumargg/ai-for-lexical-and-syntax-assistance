viod foo() {
    return;
}

int main() {
    return 0;
}