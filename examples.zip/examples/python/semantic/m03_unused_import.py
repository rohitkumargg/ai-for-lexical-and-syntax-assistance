import os
print("hi")
