x = 3
if x > 5:
    print("big")
else if x > 1:
    print("mid")
