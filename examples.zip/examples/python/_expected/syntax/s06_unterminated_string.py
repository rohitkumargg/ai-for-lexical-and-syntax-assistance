msg = "hello"
print(msg)
